import mongoose from "mongoose";

export const connectDB = async () => {
    await mongoose.connect("mongodb+srv://fmahdin112:fmahdin112@cluster0.jjrkm8g.mongodb.net/food-del").then(()=>console.log("DB Connected") );

}